<?php
add_action( 'init', 'neat_ext_register_my_taxes_gallery_filter' );
function neat_ext_register_my_taxes_gallery_filter() {
    $labels = array(
        "name" => esc_html__( 'Filters', 'neat_ext' ),
        "singular_name" => esc_html__( 'Filter', 'neat_ext' ),
    );

    $args = array(
        "label" => esc_html__( 'Filters', 'neat_ext' ),
        "labels" => $labels,
        "public" => true,
        "hierarchical" => false,
        "label" => "Filters",
        "show_ui" => true,
        "query_var" => true,
        "rewrite" => array( 'slug' => 'gallery_filter', 'with_front' => true ),
        "show_admin_column" => false,
        "show_in_rest" => false,
        "rest_base" => "",
        "show_in_quick_edit" => false,
    );
    register_taxonomy( "gallery_filter", array( "gallery" ), $args );

// End neat_ext_register_my_taxes_gallery_filter()
}
