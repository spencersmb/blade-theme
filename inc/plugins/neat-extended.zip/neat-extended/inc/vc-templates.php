<?php
/**
* VC Templates.
*/
add_action( 'init', 'visual_composer_stuff' );
function visual_composer_stuff() {

    if (class_exists('WPBakeryVisualComposerAbstract')) {

        $PATH = plugin_dir_path( __FILE__ ) . 'vc-templates/';
    
        require $PATH . 'vc-removed.php';
    
        require $PATH . 'vc-hero-header.php';
        require $PATH . 'vc-slider-header.php';
        require $PATH . 'vc-service-sidebar.php';
        require $PATH . 'vc-dual-images.php';
        require $PATH . 'vc-blog-feature.php';
        require $PATH . 'vc-process.php';
        require $PATH . 'vc-desc-image-offset.php';
        require $PATH . 'vc-faq.php';
        require $PATH . 'vc-showcase-slider.php';
        require $PATH . 'vc-custom-quote.php';
        require $PATH . 'vc-testimonials.php';
    
        if(function_exists('vc_set_as_theme')) vc_set_as_theme(true);
        
        // VC Templates
        $vc_templates_dir = $PATH;
        vc_set_template_dir($vc_templates_dir);
    
        if(function_exists('get_field')){
            require $PATH . 'vc-feature-team.php';
        }

    }
}

