<?php
vc_remove_element("vc_wp_search");
vc_remove_element("vc_wp_meta");
vc_remove_element("vc_wp_recentcomments");
vc_remove_element("vc_wp_calendar");
vc_remove_element("vc_wp_pages");
vc_remove_element("vc_wp_tagcloud");
vc_remove_element("vc_wp_custommenu");
vc_remove_element("vc_wp_text");
vc_remove_element("vc_wp_posts");
vc_remove_element("vc_wp_links");
vc_remove_element("vc_wp_categories");
vc_remove_element("vc_wp_archives");
vc_remove_element("vc_wp_rss");
vc_remove_element("vc_posts_slider");
vc_remove_element("vc_posts_grid");
vc_remove_element("vc_carousel");
vc_remove_element("vc_cta_button");
vc_remove_element("vc_cta_button2");
vc_remove_element("vc_flickr");
vc_remove_element("vc_gallery");
vc_remove_element("vc_images_carousel");
vc_remove_element("vc_tour");
vc_remove_element("vc_message");
vc_remove_element("vc_round_chart");
vc_remove_element("vc_line_chart");

//Test
vc_add_param("vc_row", array(
    "type" => "dropdown",
    "class" => "hide_in_vc_editor",
    "admin_label" => true,
    "heading" => "Row Type",
    "param_name" => "type",
    "value" => array(
        "Normal" => "normal",
        "Content" => "neat_ext_content"
    ),
    "default" => "normal",
));

//require get_template_directory() . '/inc/vc-templates/vc-hero-header.php';