<?php
/**
 * Plugin Name: Social Widget
 */

add_action( 'widgets_init', 'neat_ext_social_load_widget' );

function neat_ext_social_load_widget() {
    register_widget( 'neat_ext_social_widget' );
}

class neat_ext_social_widget extends WP_Widget {

    /**
     * Widget setup.
     */
    public function __construct() {

        /* Widget settings. */
        $widget_ops = array( 'classname' => 'neat_ext_social_widget', 'description' => __('A widget that displays your social icons', 'neat_ext_social_widget') );

        /* Widget control settings. */
        $control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'neat_ext_social_widget' );

        /* Create the widget. */
        parent::__construct( 'neat_ext_social_widget', __('Rosemary: Social Icons', 'neat_ext_social_widget'), $widget_ops, $control_ops );
    }
    function neat_ext_social_widget() {
        /* Widget settings. */
        $widget_ops = array( 'classname' => 'neat_ext_social_widget', 'description' => __('A widget that displays your social icons', 'neat_ext_social_widget') );

        /* Widget control settings. */
        $control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'neat_ext_social_widget' );

        /* Create the widget. */
        $this->WP_Widget( 'neat_ext_social_widget', __('Rosemary: Social Icons', 'neat_ext_social_widget'), $widget_ops, $control_ops );
    }

    /**
     * How to display the widget on the screen.
     */
    function widget( $args, $instance ) {
        extract( $args );

        /* Our variables from the widget settings. */
        $title = apply_filters('widget_title', $instance['title'] );
        $facebook = $instance['facebook'];
        $twitter = $instance['twitter'];
        $pinterest = $instance['pinterest'];
        $linkedIn = $instance['linkedin'];
        $googleplus = $instance['googleplus'];
        $instagram = $instance['instagram'];
        $youtube = $instance['youtube'];
        $tumblr = $instance['tumblr'];
        $vimeo = $instance['vimeo'];
        $rss = $instance['rss'];

        /* Before widget (defined by themes). */
        echo $before_widget;

        /* Display the widget title if one was input (before and after defined by themes). */
        if ( $title )
            echo $before_title . $title . $after_title;

        ?>

        <div class="social-widget">
            <?php if($facebook) : ?><a href="<?php echo get_redux_options('facebook_link'); ?>" target="_blank"><i class="fa fa-facebook"></i></a><?php endif; ?>
            <?php if($twitter) : ?><a href="<?php echo get_redux_options('twitter_link'); ?>" target="_blank"><i class="fa fa-twitter"></i></a><?php endif; ?>
            <?php if($pinterest) : ?><a href="<?php echo get_redux_options('pinterest_link'); ?>" target="_blank"><i class="fa fa-pinterest"></i></a><?php endif; ?>
            <?php if($linkedIn) : ?><a href="<?php echo get_redux_options('linkedin_link'); ?>" target="_blank"><i class="fa fa-linkedin"></i></a><?php endif; ?>
            <?php if($googleplus) : ?><a href="<?php echo get_redux_options('googleplus_link'); ?>" target="_blank"><i class="fa fa-google-plus"></i></a><?php endif; ?>
            <?php if($rss) : ?><a href="<?php echo get_redux_options('rss_link'); ?>" target="_blank"><i class="fa fa-rss"></i></a><?php endif; ?>
            <?php if($tumblr) : ?><a href="<?php echo get_redux_options('tumblr_link'); ?>" target="_blank"><i class="fa fa-tumblr"></i></a><?php endif; ?>
            <?php if($instagram) : ?><a href="<?php echo get_redux_options('instagram_link'); ?>" target="_blank"><i class="fa fa-instagram"></i></a><?php endif; ?>
            <?php if($youtube) : ?><a href="<?php echo get_redux_options('youtube_link'); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a><?php endif; ?>
            <?php if($vimeo) : ?><a href="<?php echo get_redux_options('vimeo_link'); ?>" target="_blank"><i class="fa fa-vimeo-square"></i></a><?php endif; ?>
        </div>


        <?php

        /* After widget (defined by themes). */
        echo $after_widget;
    }

    /**
     * Update the widget settings.
     */
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        /* Strip tags for title and name to remove HTML (important for text inputs). */
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['facebook'] = strip_tags( $new_instance['facebook'] );
        $instance['twitter'] = strip_tags( $new_instance['twitter'] );
        $instance['pinterest'] = strip_tags( $new_instance['pinterest'] );
        $instance['linkedin'] = strip_tags( $new_instance['linkedin'] );
        $instance['googleplus'] = strip_tags( $new_instance['googleplus'] );
        $instance['rss'] = strip_tags( $new_instance['rss'] );
        $instance['tumblr'] = strip_tags( $new_instance['tumblr'] );
        $instance['instagram'] = strip_tags( $new_instance['instagram'] );
        $instance['youtube'] = strip_tags( $new_instance['youtube'] );
        $instance['vimeo'] = strip_tags( $new_instance['vimeo'] );

        return $instance;
    }


    function form( $instance ) {

        /* Set up some default widget settings. */
        $defaults = array(
            'title' => 'Subscribe & Follow',
            'facebook' => false,
            'twitter' => false,
            'pinterest' => false,
            'linkedin' => false,
            'googleplus' => false,
            'rss' => false,
            'tumblr' => false,
            'instagram' => false,
            'youtube' => false,
            'vimeo' => false
            );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <!-- Widget Title: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>">Title:</label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:90%;" />
        </p>

        <p>Note: Set your social links in the Customizer</p>

        <p>
            <label for="<?php echo $this->get_field_id( 'facebook' ); ?>">Show Facebook:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' ); ?>" <?php checked( (bool) $instance['facebook'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'twitter' ); ?>">Show Twitter:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'twitter' ); ?>" name="<?php echo $this->get_field_name( 'twitter' ); ?>" <?php checked( (bool) $instance['twitter'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'instagram' ); ?>">Show Instagram:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'instagram' ); ?>" name="<?php echo $this->get_field_name( 'instagram' ); ?>" <?php checked( (bool) $instance['instagram'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'pinterest' ); ?>">Show Pinterest:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'pinterest' ); ?>" name="<?php echo $this->get_field_name( 'pinterest' ); ?>" <?php checked( (bool) $instance['linkedin'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'linkedin' ); ?>">Show LinkedIn:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'linkedin' ); ?>" name="<?php echo $this->get_field_name( 'linkedin' ); ?>" <?php checked( (bool) $instance['linkedin'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'googleplus' ); ?>">Show Google Plus:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'googleplus' ); ?>" name="<?php echo $this->get_field_name( 'googleplus' ); ?>" <?php checked( (bool) $instance['googleplus'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'tumblr' ); ?>">Show Tumblr:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'tumblr' ); ?>" name="<?php echo $this->get_field_name( 'tumblr' ); ?>" <?php checked( (bool) $instance['tumblr'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'youtube' ); ?>">Show Youtube:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'youtube' ); ?>" name="<?php echo $this->get_field_name( 'youtube' ); ?>" <?php checked( (bool) $instance['youtube'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'vimeo' ); ?>">Show Vimeo:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'vimeo' ); ?>" name="<?php echo $this->get_field_name( 'vimeo' ); ?>" <?php checked( (bool) $instance['vimeo'], true ); ?> />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'rss' ); ?>">Show RSS:</label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'rss' ); ?>" name="<?php echo $this->get_field_name( 'rss' ); ?>" <?php checked( (bool) $instance['rss'], true ); ?> />
        </p>


        <?php
    }
}

?>