<?php
add_action( 'init', 'sprout_ext_theme_register_my_cpts' );
function sprout_ext_theme_register_my_cpts() {

    $labels = array(
        "name" => "Gallery",
        "singular_name" => "Gallery",
    );

    $args = array(
        "labels" => $labels,
        "publicly_queryable" => true,
        "description" => "",
        'menu_icon'   => 'dashicons-format-gallery',
        "public" => true,
        "show_ui" => true,
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_rest" => true,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => true,
        "rewrite" => array( "slug" => "gallery", "with_front" => true ),
        "query_var" => true,

        "supports" => array(
            "title",
            "editor",
            "thumbnail",
            "excerpt",
            "page-attributes"
        ),
        "taxonomies" => array(
            'post_tag',
            "gallery_filter",
            'category'
        )
    );
    register_post_type( "gallery", $args );

    $labels = array(
        "name" => "Team",
        "singular_name" => "Team",
    );

    $args = array(
        "labels" => $labels,
        "publicly_queryable" => true,
        "description" => "",
        'menu_icon'   => 'dashicons-groups',
        "public" => true,
        "show_ui" => true,
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_rest" => true,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => array( "slug" => "team", "with_front" => true ),
        "query_var" => true,

        "supports" => array( "title", "page-attributes" ),
    );
    register_post_type( "team", $args );

// End of sprout_ext_theme_register_my_cpts()
}

