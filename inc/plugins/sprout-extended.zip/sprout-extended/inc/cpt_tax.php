<?php
add_action( 'init', 'sprout_ext_register_my_taxes_gallery_filter' );
function sprout_ext_register_my_taxes_gallery_filter() {
    $labels = array(
        "name" => esc_html__( 'Filters', 'sprout_ext' ),
        "singular_name" => esc_html__( 'Filter', 'sprout_ext' ),
    );

    $args = array(
        "label" => esc_html__( 'Filters', 'sprout_ext' ),
        "labels" => $labels,
        "public" => true,
        "hierarchical" => false,
        "label" => "Filters",
        "show_ui" => true,
        "query_var" => true,
        "rewrite" => array( 'slug' => 'gallery_filter', 'with_front' => true ),
        "show_admin_column" => false,
        "show_in_rest" => false,
        "rest_base" => "",
        "show_in_quick_edit" => false,
    );
    register_taxonomy( "gallery_filter", array( "gallery" ), $args );

// End sprout_ext_register_my_taxes_gallery_filter()
}
