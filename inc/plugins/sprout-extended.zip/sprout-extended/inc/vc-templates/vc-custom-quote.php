<?php
// create icon field

function sprout_ext_quote()
{

    vc_map(array(
        "name" => esc_html__("Quote Builder", "sprout_ext"),
        "category" => esc_html__("Content", "sprout_ext"),
        "description" => esc_html__("Add a Quote module", "sprout_ext"),
        "as_parent" => array('only' => 'quote__builder__item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "is_container" => true,
        "js_view" => 'VcColumnView',
        "admin_label" => true,
        "base" => "quote__builder",
        "class" => "",
        "icon" => "quote_icon",

        "params" => array(
            array(
                'type' => 'textarea',
                'heading' => esc_html__( 'Header Text', 'sprout_ext' ),
                'description' => esc_html__( 'Enter header title text.', 'sprout_ext' ),
                "value" => '',
                "admin_label" => true,
                'param_name' => 'header_text',
            ),
            array(
                "type" => "dropdown",
                "admin_label" => false,
                "heading" => esc_html__('Select Left or Centered or No Header Topped', 'sprout'),
                "param_name" => "neat_heading",
                "value" => array(
                    "None" => "none",
                    "Center" => "center",
                    "Left" => "left",
                    "Center Mobile, Left Desktop" => "center_mobile"
                ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Header Text Color", "sprout_ext"),
                "value" => '#424242',
                "class" => "hide_in_vc_editor",
                "param_name" => "header_text_color",
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__( 'Subtext', 'sprout_ext' ),
                'description' => esc_html__( 'Enter text.', 'sprout_ext' ),
                'param_name' => 'subtext',
                "class" => "hide_in_vc_editor",
                "holder" => "div",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Subtext Color", "sprout_ext"),
                "value" => '#424242',
                "class" => "hide_in_vc_editor",
                "param_name" => "subtext_color",
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__( 'Contact Subtext', 'sprout_ext' ),
                'description' => esc_html__( 'Enter text.', 'sprout_ext' ),
                'param_name' => 'contact_text',
                "holder" => "div",
                "class" => "hide_in_vc_editor",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Contact Subtext Color", "sprout_ext"),
                "value" => '#424242',
                "class" => "hide_in_vc_editor",
                "param_name" => "contact_text_color",
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Link Text', 'sprout_ext' ),
                'description' => esc_html__( 'Enter text.', 'sprout_ext' ),
                'param_name' => 'link_text',
                "holder" => "div",
                "class" => "hide_in_vc_editor",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Link Text Color", "sprout_ext"),
                "value" => '#5F9F18',
                "class" => "hide_in_vc_editor",
                "param_name" => "link_text_color",
            ),
            array(
                'type' => 'dropdown',
                'heading' => esc_html__( 'Contact page link', 'sprout_ext' ),
                'description' => esc_html__( 'Select a page link for contact.', 'sprout_ext' ),
                "admin_label" => false,
                "class" => "hide_in_vc_editor",
                'param_name' => 'custom_link',
                "value" => sprout_ext_getAllPages('page')
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                "admin_label" => false,
                "class" => "hide_in_vc_editor",
                'holder'      => 'div'
            ),
            array(
                'type' => 'css_editor',
                'heading' => __( 'Css', 'sprout_ext' ),
                'param_name' => 'css',
                'group' => esc_html__( 'Design options', 'sprout_ext' ),
            )

        )

    ));

    $dhvc = '';
    if( function_exists('neat_getAllDHVC_forms') ){
        $dhvc = neat_getAllDHVC_forms();
    } else {
        $dhvc = '';
    }
    vc_map( array(
        "name"      => esc_html__( "Quote Item", "sprout_ext" ),
        "base"      => "quote__builder__item",
        'icon'        => 'quote_item_icon',
        "as_child" => array('only' => 'quote__builder'),
        "as_parent" => array('only' => 'quote_bullet'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "is_container" => true,
        "js_view" => 'VcColumnView',
        'description' => esc_html__( 'Add an item to the Quote Builder.', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Title', 'sprout_ext' ),
                'param_name' => 'title',
                "admin_label" => true,
                'description' => esc_html__( 'Add title.', 'sprout_ext' ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Title Color", "sprout_ext"),
                "class" => "hide_in_vc_editor",
                "value" => '#222228',
                "param_name" => "title_color",
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Cost', 'sprout_ext' ),
                'param_name' => 'cost',
                "admin_label" => true,
                'description' => esc_html__( 'Add a price.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Short Description', 'sprout_ext' ),
                'param_name' => 'desc',
                "admin_label" => false,
                'description' => esc_html__( 'Add a short description of the plan.', 'sprout_ext' ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__("Description Text Color", "sprout_ext"),
                "value" => '#222228',
                "param_name" => "desc_color",
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Button Text', 'sprout_ext' ),
                'param_name' => 'button_text',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for the button.', 'sprout_ext' ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__("Button Color", "sprout_ext"),
                "value" => '#53950C',
                "param_name" => "button_color",
            ),
            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__( 'Background Image', 'sprout_ext' ),
                'description' => esc_html__( 'Place an image at the bottom of selected card.', 'sprout_ext' ),
                "param_name" => "bg_image",
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                'holder'      => 'div'
            ),
            array (
                'type' => 'dropdown',
                'heading' => esc_html__( 'Select Form', 'sprout_ext' ),
                'param_name' => 'dhvc_form_select',
                "admin_label" => true,
                'description' => esc_html__( 'Add form.', 'sprout_ext' ),
                "value" => $dhvc
            )
        )
    ) );
    vc_map(array(
        "name" => esc_html__("Item Bullet", "sprout_ext"),
        "category" => esc_html__("Content", "sprout_ext"),
        "as_child" => array('only' => 'quote__builder__item'),
        "description" => esc_html__("Add a bullet item to the plan", "sprout_ext"),
        "base" => "quote_bullet",
        "class" => "",
        "icon" => "quote_bullet_icon",

        "params" => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Item Text', 'sprout_ext' ),
                'description' => esc_html__( 'Enter item text.', 'sprout_ext' ),
                "value" => '',
                "admin_label" => true,
                'param_name' => 'bullet_text',
            ),
            array(
                "type" 			=> "icon",
                "class" 		=> "hide_in_vc_editor",
                "admin_label" 	=> true,
                "heading" 		=> "Icon",
                "param_name" 	=> "fa_icon",
                "admin_label" 	=> false,
                "value" 		=> "fa-bookmark"
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Icon Color", "sprout_ext"),
                "value" => '#3A3B3D',
                "class" => "hide_in_vc_editor",
                "param_name" => "icon_color",
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )

        )

    ));

    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_quote__builder extends WPBakeryShortCodesContainer {
        }
    }
    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_quote__builder__item extends WPBakeryShortCodesContainer {
        }
    }
}
sprout_ext_quote();
add_shortcode_param('icon' , 'sprout_ext_icon_field');

// [quote]
function sprout_ext_quote_shortcode($params = array(), $content = null, $content_html) {
    extract(shortcode_atts(array(
        'class' => '',
        'header_text' => '',
        'header_text_color' => '#424242',
        'button_color' => '#53950C',
        'subtext' => '',
        'subtext_color' => '#424242',
        'contact_text' => '',
        'contact_text_color' => '#424242',
        'link_text' => '',
        'link_text_color' => '#5F9F18',
        'custom_link' => '',
        'neat_heading' => '',
        'css' => ''
    ), $params));

//echo "<pre>";
//print_r($params);
//echo "</pre>";

    $css_class = apply_filters(
        VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
        vc_shortcode_custom_css_class( $css, ' ' )
    );

    $h2_array = array(
        'h2' => array(
            'br' => array(),
            'class' => array()
        ),
        'class' => array(),
        'br' => array()
    );


    $content = do_shortcode($content);

    $quote_output = '
    <!-- quote container -->
    <div class="quote container'. esc_attr( $css_class ).' '. esc_attr( $class ) .'">
    
        <div class="quote__form--select active">
        
            <div class="container-fluid no-padding">
                <div class="col-xs-12 col-md-4 col-lg-5">
                
                    <div class="quote__chooser">';

    // Header topper check
    if($neat_heading === 'center') {
        $quote_output .= '
                            <h2 class="bold blade-header-topper" style="color:' . esc_attr($header_text_color) . '">
                                ' . wp_kses($header_text, $h2_array, 'sprout_ext') . '
                            </h2>';
    }else if($neat_heading === 'center_mobile'){
        $quote_output .= '
                            <h2 class="bold blade-header-topper header-topper-mobile" style="color:'.esc_attr($header_text_color).'">
                                '.wp_kses($header_text, $h2_array, 'sprout_ext' ).'
                            </h2>';
    }else if($neat_heading === 'left'){
        $quote_output .= '
                            <h2 class="bold blade-header-topper header-topper-left" style="color:'.esc_attr($header_text_color).'">
                                '.wp_kses($header_text, $h2_array, 'sprout_ext' ).'
                            </h2>';
    }else{
        $quote_output .= '
                            <h2 class="bold" style="color:'.esc_attr($header_text_color).'">
                                '.wp_kses($header_text, $h2_array, 'sprout_ext' ).'
                            </h2>';
    }

    $quote_output .= '
                        <div class="quote__select--btn">
                           
                            <p class="fieldset" data-color="'.esc_attr($button_color).'">
                                
                            </p>
                        
                        </div>
                        
                        <div class="quote__chooser--desc hidden-xs">
                            <p style="color:'.esc_attr($subtext_color).'">'.wp_kses($subtext, 'sprout_ext').'</p>
                            
                            <span style="color:'.esc_attr($contact_text_color).'">'.wp_kses($contact_text, 'sprout_ext').'<a href="'.esc_url(get_permalink($custom_link)).'" style="color:'.esc_attr($link_text_color).'">'.wp_kses($link_text, 'sprout_ext').'</a></span>
                        </div>
                        
                    </div>
                    
                </div> 
                
                <div class="col-xs-12 col-md-8 col-lg-7">
                    <div class="card__item--wrapper">
                        '.$content.'
                    </div>
                </div>
            </div>
            
        </div>
        <!-- end quote form select -->
        
        <div class="quote__form--input">
            <!-- place quote form inside here -->
            
            <div class="quote__form--card">
                <div class="tablet visible-xs visible-sm">
                    <div class="tablet__card--header">
                        <span>'. esc_html__('Selected', 'sprout_ext').'</span>
                        <h2>'. esc_html__('Residential', 'sprout_ext').'</h2>
                        <a class="rounded-btn white-btn go-back" href="#">'. esc_html__('Selected', 'Go Back').'</a>
                    </div>
                    
                </div>
                <div class="quote__form--card-wrapper">
                
                </div><!-- end quote__form card-wrapper -->
                
            </div><!-- end quote__form card -->
            
            <div class="quote__form--vc">
            </div>
            
        </div><!-- end quote form input -->
        
    </div><!-- end quote container -->
	';

    return $quote_output;
}
add_shortcode('quote__builder', 'sprout_ext_quote_shortcode');

// [quote_item]
add_shortcode( 'quote__builder__item', 'sprout_ext_quote_item_func' );
function sprout_ext_quote_item_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'title' => '',
        'title_color' => '',
        'cost' => '',
        'desc' => '',
        'desc_color' => '',
        'button_text' => '',
        'button_color' => '',
        'form_builder_name' => '',
        'form_builder_id' => '',
        'dhvc_form_select' => '',
        'bg_image' => '',

    ), $atts ) );

    // Bullet Content
    $content = do_shortcode($content);

    //Build Form
    $form_output = '';

    if( $dhvc_form_select !== ''){
        $form_output = do_shortcode('[dhvc_form id="'.$dhvc_form_select.'"]');
        $form_output = do_shortcode('[dhvc_form id="3482"]');
    }

    if (is_numeric($bg_image)) {
        $bg_image = wp_get_attachment_url($bg_image);
    }

    // Build Output
    $output = '
        <!-- quote item select -->
        <div class="card__item quote__item '.esc_attr($class).'">

            <div class="card__item--content">
            
                <h2 style="color:'.esc_attr($title_color).'" >'. wp_kses($title, 'sprout_ext') .'</h2>
                <span class="rounded-btn black-btn price black">'. wp_kses($cost, 'sprout_ext') .'</span>
                <h3 class="desc">'. wp_kses($desc, 'sprout_ext') .'</h3>
                <ul class="card__list">
                    '.$content.'
                </ul>
                
                <a class="card__item--btn rounded-btn filled" href="#">'. wp_kses($button_text, 'sprout_ext') .'</a>
                
            </div>
            <div class="card__image">';

    // IMG check
    if(is_numeric($bg_image)){
        $output .= '<img src="'.esc_url($bg_image).'" alt="">';
    }

    $output .= '
            </div>
            <!-- quote item form temp -->
            <div class="quote__form--temp">
                <div class="quote__form--inner">';
    if(strlen($form_output) > 0){
        $output .= $form_output;
    }
    $output .= '  
                </div>
            </div>
        </div>
    ';

    return $output;
}

// [quote_bullet]
add_shortcode( 'quote_bullet', 'sprout_ext_quote_bullet_func' );
function sprout_ext_quote_bullet_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'bullet_text' => '',
        'fa_icon' => '',
        'icon_color' => ''

    ), $atts ) );

    // Build Output
    $output = '
        <li class="'.esc_attr($class).'">
            <i class="fa '.esc_attr($fa_icon).'" style="color:'.esc_attr($icon_color).'"></i>'.wp_kses($bullet_text, 'sprout_ext').'
        </li>
    ';

    return $output;
}