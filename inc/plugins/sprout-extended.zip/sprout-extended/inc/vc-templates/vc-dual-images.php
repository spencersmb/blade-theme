<?php
function sprout_ext_dual_images()
{

    vc_map(array(
        "name" => esc_html__("Dual Images", "sprout_ext"),
        "category" => esc_html__("Content", "sprout_ext"),
        "description" => esc_html__("Place Two Overlapping Images", "sprout_ext"),
        "base" => "dual_images",
        "class" => "et-dual-image",
        "icon" => "dual_images",

        "params" => array(

            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                "heading" => "Image One",
                "param_name" => "image_1",
            ),
            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                "heading" => "Image Two",
                "param_name" => "image_2",
            )
        )

    ));
}
sprout_ext_dual_images();

// [dual_images]
function sprout_ext_dual_images_shortcode($params = array(), $content = null) {
    extract(shortcode_atts(array(
        'image_1' => '',
        'image_2' => ''
    ), $params));

    $image_1_alt = '';
    $image_2_alt = '';

    if (is_numeric($image_1)) {
        $image_1_alt = get_post_meta( $image_1, '_wp_attachment_image_alt', 'true');
        $image_1 = wp_get_attachment_url($image_1);
    }
    if (is_numeric($image_2)) {
        $image_2_alt = get_post_meta( $image_2, '_wp_attachment_image_alt', 'true');
        $image_2 = wp_get_attachment_url($image_2);
    }

    $dual_images_output = '
    <!-- dual images -->
    <div class="dual-images-container">
        <div class="image-1">
            <img class="img-responsive shadow-medium-dark" src="'.esc_url($image_1).'" alt="'.esc_attr($image_1_alt).'">
        </div>
        <div class="image-2">
            <img class="img-responsive shadow-medium-dark" src="'.esc_url($image_2).'" alt="'.esc_attr($image_2_alt).'">
        </div>
    </div>
    <!-- end dual images -->
	';

    return $dual_images_output;
}
add_shortcode('dual_images', 'sprout_ext_dual_images_shortcode');

