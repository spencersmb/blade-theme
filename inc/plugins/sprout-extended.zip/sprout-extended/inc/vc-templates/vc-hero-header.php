<?php
function sprout_ext_hero_header()
{

    vc_map(array(
        "name" => esc_html__("Hero Header", "sprout_ext"),
        "category" => esc_html__("Content", "sprout_ext"),
        "description" => esc_html__("Place Header", "sprout_ext"),
        "base" => "hero",
        "class" => "",
        "icon" => "hero_icon",

        "params" => array(

            array(
                "type" => "textfield",
                "holder" => "div",
                "admin_label" => false,
                "heading" => esc_html__("Title", "sprout_ext"),
                "param_name" => "title",
            ),

            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__("Subtitle", "sprout_ext"),
                "param_name" => "subtitle",
                "admin_label" => true,
            ),

            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Title Color", "sprout_ext"),
                "param_name" => "title_color",
            ),

            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Subtitle Color", "sprout_ext"),
                "param_name" => "subtitle_color",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Divider Color", "sprout_ext"),
                "param_name" => "divider_color",
                "value" => "#fff"
            ),

            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Background Color", "sprout_ext"),
                "param_name" => "bg_color",
                "value" => "#78be01"
            ),

            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => "Background Image",
                "param_name" => "bg_image",
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )

    ));
}
sprout_ext_hero_header();

// [hero]
function sprout_ext_hero_header_shortcode($params = array(), $content = null) {
    extract(shortcode_atts(array(
        'class' => '',
        'title' => 'Title',
        'subtitle' => 'Subtitle',
        'title_color' => '#fff',
        'subtitle_color' => '#fff',
        'divider_color' => '#fff',
        'bg_color' => '#78be01',
        'bg_image' => ''
    ), $params));

    $banner_with_img = '';

    if (is_numeric($bg_image)) {
        $bg_image = wp_get_attachment_url($bg_image);
        $banner_with_img = 'banner_with_img';
    }

    $hero_header = '
    
    <!-- hero section -->
	<div class="hero m-header scene_element scene_element--fadein '.esc_attr($class).'" style="background-color:'. esc_attr($bg_color) .'">

		<div class="header-slider-divider">
           <div class="divider-svg">
                <svg xmlns="http://www.w3.org/2000/svg" width="1200" height="65" fill="'. esc_attr($divider_color) .'" viewBox="0 0 1212.4 64.6" class="divider-svg">
                    <polygon points="606.2 40.9 0 0 0 64.6 595.2 64.6 617.2 64.6 1212.4 64.6 1212.4 0 "  fill="'. esc_attr($divider_color) .'" class="divider-path"/>
                </svg>
           </div>
		</div>
        
		<div class="hero-background img-loader-bg delay-5" style="background-image:url('.esc_url($bg_image).')"></div>
        <!-- end background-image -->
        
		<div class="hero-wrapper">
		
			<div class="hero-content">
			
				<div class="hero-content-inner">
					<h2 class="hero-title" style="color:'.esc_attr($title_color).' !important">'.wp_kses($title, 'sprout_ext').'</h2>
					<h4 class="hero-subtitle" style="color:'.esc_attr($subtitle_color).' !important">'.wp_kses($subtitle, 'sprout_ext').'</h4>
				</div>
				<!-- end hero-content-inner -->
				
			</div>
			<!-- end hero-content -->
			
		</div>
		<!-- end hero wrapper -->
		
	</div>
	<!-- end hero section -->
	';

    return $hero_header;
}
add_shortcode('hero', 'sprout_ext_hero_header_shortcode');

