<?php
function sprout_ext_inline_block()
{

    vc_map(array(
        "name" => esc_html__("Inline Image + text block", "sprout_ext"),
        "category" => esc_html__("Content", "sprout_ext"),
        "description" => esc_html__("Text next to an image inline", "sprout_ext"),
        "base" => "inline_block",
        "class" => "et-dual-image",
        "icon" => "inline_block_icon",

        "params" => array(

            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                "heading" => esc_html__("Select image", "sprout_ext"),
                "param_name" => "image",
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__( "Headline", "sprout_ext" ),
                "param_name" => "headline",
                "value" => '',
                "description" => esc_html__( "A Short headline.", "sprout_ext" )
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__( "Add a short desc", "sprout_ext" ),
                "param_name" => "desc",
                "value" => '',
                "description" => esc_html__( "Add padding top to container in PX.", "sprout_ext" )
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )

        )

    ));
}
sprout_ext_inline_block();

// [inline_block]
function sprout_ext_inline_block_shortcode($params = array(), $content = null) {
    extract(shortcode_atts(array(
        'image' => '',
        'headline' => '',
        'desc' => '',
        'class' => ''
    ), $params));

    $image_alt= '';

    if (is_numeric($image)) {
        $image_alt = get_post_meta( $image, '_wp_attachment_image_alt', 'true');
        $image = wp_get_attachment_image_url($image, 'medium');
    }


    $inline_block_output = '
    <!-- dual images -->
    <div class="inline__block '.esc_attr($class).'">
        <div class="inline__image">
            <img class="img-responsive" src="'.esc_url($image).'" alt="'.esc_attr($image_alt).'">
        </div>
        <div class="inline__desc">
            <h4>'. wp_kses($headline, 'sprout_ext') .'</h4>
            <p>'. wp_kses($desc, 'sprout_ext') .'</p>
        </div>
    </div>
    <!-- end dual images -->
	';

    return $inline_block_output;
}
add_shortcode('inline_block', 'sprout_ext_inline_block_shortcode');

