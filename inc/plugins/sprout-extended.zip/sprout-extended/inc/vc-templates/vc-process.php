<?php
function sprout_ext_process_vc_func() {
    vc_map( array(
        "name"      => esc_html__( "Process Map", "sprout_ext" ),
        "base"      => "process",
        'icon'        => 'process_icon',
        "as_parent" => array('only' => 'process_item, vc_single_image'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "is_container" => true,
        "js_view" => 'VcColumnView',
        'description' => esc_html__( 'Create a process Map. Add up to six items', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(

            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                "heading" => "Center Image",
                "description" => esc_html__( "Choose a center image, must be square dimension.", "sprout_ext" ),
                "param_name" => "image",
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )
    ) );
    vc_map( array(
        "name"      => esc_html__( "Process Item", "sprout_ext" ),
        "base"      => "process_item",
        'icon'        => 'process_item_icon',
        "as_child" => array('only' => 'process'),
        'description' => esc_html__( 'Add an item to the process Map.', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(

            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__( "Header", "sprout_ext" ),
                "param_name" => "item_header_text",
                "value" => '',
                "description" => esc_html__( "Add Header text.", "sprout_ext" )
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__( "Header text color", "sprout_ext" ),
                "param_name" => "header_color",
                "value" => '#35373D', //Default White
                "description" => esc_html__( "Choose header text color", "sprout_ext" )
            ),
            array(
                "type" => "textarea",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__( "Text", "sprout_ext" ),
                "param_name" => "item_text",
                "value" => '',
                "description" => esc_html__( "Add short description.", "sprout_ext" )
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__( "Text color", "sprout_ext" ),
                "param_name" => "text_color",
                "value" => '#727272', //Default P color
                "description" => esc_html__( "Choose text color", "sprout_ext" )
            ),
            array(
                "type" 			=> "icon",
                "class" 		=> "hide_in_vc_editor",
                "admin_label" 	=> true,
                "heading" 		=> "Icon",
                "param_name" 	=> "fa_icon",
                "admin_label" 	=> false,
                "value" 		=> "fa-wheelchair"
            ),
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_html__( "Icon color", "sprout_ext" ),
                "param_name" => "icon_color",
                "value" => '#95989A', //Default Red color
                "description" => esc_html__( "Choose text color", "sprout_ext" )
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )
    ) );

    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_Process extends WPBakeryShortCodesContainer {
        }
    }
};
sprout_ext_process_vc_func();

// [process]
add_shortcode( 'process', 'sprout_ext_process_func' );
function sprout_ext_process_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'header_color' => '',
        'text_color' => '#727272',
        'image' => ''

    ), $atts ) );

    //Inner content
    $content = do_shortcode($content);

    // Build Output
    $output = '
    <div class="process-container '.esc_attr($class).'" style="">
            
            '.$content;

    $output .= '
    </div><!-- end process container -->
    ';

    return $output;
}

// [process_item]
add_shortcode( 'process_item', 'sprout_ext_process_item_func' );
function sprout_ext_process_item_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'fa_icon' => '',
        'item_header_text' => '',
        'header_color' => '',
        'item_text' => '',
        'text_color' => '',
        'icon_color' => '',

    ), $atts ) );

    // Build Output
    $output = '
    <div class="col-xs-12 col-sm-4 process-item-container '.esc_attr($class).'">
        <div class="process-item-inner '. esc_attr($class) .'">';

    $output .= '
            <div class="process-item-header">
                <h6 style="color: '.esc_attr($header_color).'"><span><i style="color: '.esc_attr($icon_color).'" class="fa '.esc_attr($fa_icon).'"></i></span>'. wp_kses($item_header_text, 'sprout_ext') .'</h6>
            </div>
            <div class="process-item-text">
                <p style="color: '.esc_attr($text_color).'">'. wp_kses($item_text, 'sprout_ext') .'</p>
            </div>
    ';

    $output .= '
        </div>
    </div>
    <!-- end process item container -->
    ';

    return $output;
}


