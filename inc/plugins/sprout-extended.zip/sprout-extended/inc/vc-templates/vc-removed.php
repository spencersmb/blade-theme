<?php
vc_remove_element("vc_wp_search");
vc_remove_element("vc_wp_meta");
vc_remove_element("vc_wp_recentcomments");
vc_remove_element("vc_wp_calendar");
vc_remove_element("vc_wp_pages");
vc_remove_element("vc_wp_tagcloud");
vc_remove_element("vc_wp_text");
vc_remove_element("vc_wp_posts");
vc_remove_element("vc_wp_links");
vc_remove_element("vc_wp_categories");
vc_remove_element("vc_wp_archives");
vc_remove_element("vc_wp_rss");
vc_remove_element("vc_posts_slider");
vc_remove_element("vc_posts_grid");
vc_remove_element("vc_carousel");
vc_remove_element("vc_cta_button");
vc_remove_element("vc_cta_button2");
vc_remove_element("vc_flickr");
vc_remove_element("vc_gallery");
vc_remove_element("vc_images_carousel");
vc_remove_element("vc_tour");
vc_remove_element("vc_message");
vc_remove_element("vc_round_chart");
vc_remove_element("vc_line_chart");

/**
 * Custom VC_ROW
 *
 * @package Neat
 */
vc_add_param("vc_row",
    array(
        "type" => "dropdown",
        "admin_label" => false,
        "heading" => esc_html__("Row Type", 'sprout'),
        "param_name" => "type",
        "value" => array(
            "Normal" => "normal",
            "Content" => "sprout_ext_content"
        ),
        "default" => "normal",
    )
);

vc_add_param("vc_row",
    array(
        "type" => "dropdown",
        "admin_label" => false,
        "heading" => esc_html__("Animation Type", 'sprout'),
        "param_name" => "animate",
        "value" => array(
            "None" => "none",
            "Fade" => "fade",
            "Fade In & Up" => "animate_up",
            "Fade In Right" => "animate_right",
            "Fade In Left" => "animate_left"
        ),
        "default" => "none",
    )
);

vc_add_param("vc_row",
    array(
        "type" => "checkbox",
        "admin_label" => false,
        "heading" => esc_html__("Angled Divider", 'sprout'),
        "param_name" => "divider",
    )
);

vc_add_param("vc_row",
    array(
        "type" => "checkbox",
        "admin_label" => false,
        "heading" => esc_html__("Background Image preload", 'sprout'),
        "description" => esc_html__("Enable the background image to preload while the page is rendering", 'sprout'),
        "param_name" => "bg_preload",
    )
);

vc_add_param("vc_row",
    array(
        "type" => "colorpicker",
        "admin_label" => false,
        "heading" => esc_html__("Choose divider color", 'sprout'),
        "param_name" => "divider_color",
        "value" => "#fff"
    )
);

/**
 * Custom VC_INNER_ROW
 *
 * @package Neat
 */


vc_add_param("vc_row_inner",
    array(
        "type" => "dropdown",
        "admin_label" => false,
        "heading" => esc_html__("Row type", 'sprout'),
        "param_name" => "row_type",
        "value" => array(
            "Full Width" => "none",
            "Contained" => "contained",
        ),
    )
);

vc_add_param("vc_row_inner",
    array(
        "type" => "dropdown",
        "admin_label" => false,
        "heading" => esc_html__("Animation Type", 'sprout'),
        "param_name" => "animate",
        "value" => array(
            "None" => "none",
            "Fade" => "fade",
            "Fade In & Up" => "animate_up",
            "Fade In Right" => "animate_right",
            "Fade In Left" => "animate_left"
        ),
        "default" => "none",
    )
);

/**
 * Custom VC_COLUMN
 *
 * @package Neat
 */
vc_add_param("vc_column",
    array(
        "type" => "dropdown",
        "admin_label" => false,
        "heading" => esc_html__("Animation Type", 'sprout'),
        "param_name" => "animate",
        "value" => array(
            "None" => "none",
            "Fade" => "fade",
            "Fade In & Up" => "animate_up",
            "Fade In Right" => "animate_right",
            "Fade In Left" => "animate_left"
        ),
        "default" => "none",
    )
);

/**
 * Custom VC_CUSTOM_HEADER
 *
 * @package Neat
 */

vc_add_param("vc_custom_heading",
    array(
        "type" => "dropdown",
        "admin_label" => false,
        "heading" => esc_html__("Select Left or Centered or No Header Topped", "sprout_ext"),
        "param_name" => "neat_heading",
        "value" => array(
            "None" => "none",
            "Center" => "center",
            "Left" => "left"
        ),
    )
);