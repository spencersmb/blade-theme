<?php
function sprout_ext_get_postTags_string($postId){
    //Get tags
    $get_tags = get_the_tags($postId); //$tag_name[0]->name
    $tags_arr = array();
    $tags = '';

    //safety check for empty tag value
    if( $get_tags != "" ){
        foreach($get_tags as $tag){
            $tags_arr[] = $tag->name;
        }

        $tags = join(', ', $tags_arr );

    }

    return $tags;

}

function sprout_ext_getPosts($services, $post_type, $order_type, $order_by){

    // convert string ids to Num
    $string_services = explode(',', $services, 80);
    foreach ($string_services as $key => $value){
        $string_services[$key] = (int)($value);
    }

    //create loop args
    $args = array(
        'post_type' => $post_type,
        'post__in' => $string_services,
        'order' => $order_type,
        'orderby' => $order_by,
        'posts_per_page' => 10
    );


    // Get sticky posts
    $posts = get_posts( $args );

    return $posts;
}

function sprout_ext_build_showcase_images($posts){
    $output = '';
    $postCount = 0;

    foreach ($posts as $post){

        $postId = get_post_thumbnail_id($post->ID);
        $featured_image = wp_get_attachment_image_url( $postId, 'sprout-gallery-thumb-sm' );
        $thumb_image = wp_get_attachment_image_url($postId, 'thumbnail');
        $image_alt = get_post_meta( $postId, '_wp_attachment_image_alt', 'true');

        $output .= '<li 
                        data-index="'. esc_attr($postCount) .'" 
                        data-thumb="'. esc_url($thumb_image) .'"
                        data-alt="'. esc_attr($image_alt) .'">
                            <img src="'. esc_url($featured_image) .'" alt="'.esc_attr($image_alt).'">
                        </li>';

        $postCount++;

    }

    return $output;
}

function sprout_ext_build_showcase_desc($posts, $button_text){
    $output ='';
    $postCount = 0;

    foreach ($posts as $post){

        $excerpt = get_the_excerpt($post->ID);
        $excerpt_trim = wp_trim_words( $excerpt , '25' );

        //Get tags
        $get_tags = sprout_ext_get_postTags_string($post->ID);

        $output .= '
       
        <div class="showcase__desc--item" data-index="'. esc_attr($postCount) .'">
            <span>'.$get_tags.'</span>
            <h2>'. get_the_title($post->ID) .'</h2>
            <p>'.wp_kses($excerpt_trim, 'sprout_ext').'</p>
            
            <a 
                href="'.esc_url(get_the_permalink($post->ID)).'"
                class="rounded-btn global-color">'.wp_kses($button_text, 'sprout_ext').'</a>
        </div>
        <!-- end showcase__desc item -->
        ';

        $postCount++;

    }

    return $output;
}

function sprout_ext_showcase_vc_func() {
    vc_map( array(
        "name"      => esc_html__( "Showcase Slider", "sprout_ext" ),
        "base"      => "showcase",
        'icon'        => 'showcase_icon',
        'description' => esc_html__( 'Create a showcase slider', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(

            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__( "Background Slider color", "sprout_ext" ),
                "param_name" => "bg_color_inner",
                "value" => '#8ED72B',
                "description" => esc_html__( "Choose a color for the inner background of the slider", "sprout_ext" )
            ),
            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => "Main Background Image",
                "description" => esc_html__( "Choose a background image", "sprout_ext" ),
                "param_name" => "bg_outer_image",
            ),
            array(
                'param_name'  => 'selected_services',
                "admin_label" => false,
                'heading'     => esc_html__( 'Select Featured Projects', 'sprout_ext' ),
                'description' => esc_html__( 'Choose projects to add to slider', 'sprout_ext' ),
                'type'        => 'checkbox',
                "class"       => "sprout_ext-service-checkbox",
                "value"			=> sprout_ext_getAllPages('gallery')
            ),
            array(
                'param_name'  => 'order_type',
                'heading'     => esc_html__( 'Select Project Order type:', 'sprout_ext' ),
                'description' => esc_html__( 'You can choose how to order your projects with these options.', 'sprout_ext' ),
                'type'        => 'dropdown',
                'class' => 'hide_in_vc_editor',
                'admin_label' => false,
                'value'			=> array(
                    'Ascending' => 'ASC',
                    'Descending' => 'DESC'
                )
            ),
            array(
                'param_name'  => 'order_by',
                'heading'     => esc_html__( 'Select Project Order by:', 'sprout_ext' ),
                'description' => esc_html__( 'Default is by project date, but you can change to alphabetical, or specific post ID', 'sprout_ext' ),
                'type'        => 'dropdown',
                'class' => 'hide_in_vc_editor',
                'admin_label' => false,
                'value'			=> array(
                    'None' => 'none',
                    'ID' => 'ID',
                    'Date' => 'date',
                    'Title' => 'title'
                )
            ),
            array(
                'param_name'  => 'button_text',
                'heading'     => esc_html__( 'Button Text', 'sprout_ext' ),
                'description' => esc_html__( 'Add a call to action.', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                'holder'      => 'div',
                'value' => 'View Project'
            ),
            array(
                'param_name'  => 'tab_text',
                'heading'     => esc_html__( 'Tab Text', 'sprout_ext' ),
                'description' => esc_html__( 'Change the text on the small tab.', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                'holder'      => 'div',
                'value' => 'showcase'
            ),
            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => "Tab Image",
                "description" => esc_html__( "Change the small tab image.", "sprout_ext" ),
                "param_name" => "tab_image",
            ),
            array(
                'param_name'  => 'padding_top',
                'heading'     => esc_html__( 'Padding Top', 'sprout_ext' ),
                'description' => esc_html__( 'Enter spacing for the top of the slider in px', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                'holder'      => 'div'
            ),
            array(
                'param_name'  => 'padding_bottom',
                'heading'     => esc_html__( 'Padding Bottom', 'sprout_ext' ),
                'description' => esc_html__( 'Enter spacing for the top of the slider in px', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                'holder'      => 'div'
            ),
            array(
                'param_name'  => 'padding_left_right',
                'heading'     => esc_html__( 'Padding Right and Left', 'sprout_ext' ),
                'description' => esc_html__( 'Enter spacing for the left and right sides of the slider in px', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                'holder'      => 'div'
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )
    ) );
};
sprout_ext_showcase_vc_func();

// [showcase]
add_shortcode( 'showcase', 'sprout_ext_showcase_func' );
function sprout_ext_showcase_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'selected_services' => '',
        'bg_image' => '',
        'bg_color_inner' => '',
        'bg_outer_image' => '',
        'padding_top' => '80px',
        'padding_bottom' => '80px',
        'padding_left_right' => '6%',
        'button_text' => 'View Project',
        'tab_image' => get_template_directory_uri() .'/assets/images/showcase-arrow.png',
        'tab_text' => 'showcase',
        'order_type' => 'asc',
        'order_by' => 'none'

    ), $atts ) );

    $feature_bg_image = "";

    if (is_numeric($bg_outer_image)) {
        $feature_bg_image = wp_get_attachment_url($bg_outer_image);
    }

    if (is_numeric($tab_image)) {
        $tab_image = wp_get_attachment_url($tab_image);
    }

    // Build posts object array
    $posts = sprout_ext_getPosts($selected_services, 'gallery', $order_type, $order_by);

    // Build Output
    $output = '
    
    <div class="showcase '. esc_attr( $class ) .'" style="padding: '. esc_attr($padding_top) .' '. esc_attr($padding_left_right) .' '. esc_attr($padding_bottom) .';">
        <div class="showcase__outer--bgimage shadow-medium-dark" style="background-image: url('.esc_url($feature_bg_image).')">
        
            <div class="showcase__outer--bgcolor" style="background-color:'.esc_attr($bg_color_inner).'">
            
                <div class="showcase__inner shadow-medium">
                    <div class="showcase__tab">
                        <div class="showcase__tab--img">
                            <img class="img-responsive" src="'.esc_url($tab_image).'" alt="'.esc_html__('arrow', 'sprout_ext').'">
                        </div>
                        <span>'.wp_kses($tab_text,'sprout_ext').'</span>
                    </div>
            
                    <div class="showcase__slider--content">
                        <div class="count">
                            <span class="current">'. esc_html__("1", "sprout_ext") .'</span> '. esc_html__("/", "sprout_ext") .' <span class="total"></span>
                        </div>
                        <div class="showcase__thumbs">
                            <div class="showcase__thumbs--inner">
                                <ul class="showcase__thumbs--images">
                                   
                                </ul>
                            </div>
                            <ul class="showcase__thumbsnav">
                                <li><a href="#" class="showcase__thumbsnav--prev"><i class="fa fa-chevron-right" aria-hidden="true"></i></a></li>
                                <li><a href="#" class="showcase__thumbsnav--next"><i class="fa fa-chevron-right" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                        <!-- end thumbs -->
                        
                        <div class="showcase__items--container">

                            <div class="showcase__item">
                            
                                <div class="showcase__slider--wrapper">
                                
                                    <ul class="showcase__slider--gallery">
                                    
                                    '.sprout_ext_build_showcase_images($posts).'
                                    
                                    </ul>
                                    
                                    <ul class="showcase__nav">
                                        <li><a href="#" class="showcase__nav--prev">'.esc_html__('Prev', 'sprout_ext').'</a></li>
                                        <li><a href="#" class="showcase__nav--next">'.esc_html__('Next', 'sprout_ext').'</a></li>
                                    </ul>
                                    <!-- end showcase nav -->
                                    
                                </div>
                                <!-- end showcase__slider wrapper -->
                                
                                <div class="showcase__desc">
                                
                                    '.sprout_ext_build_showcase_desc($posts, $button_text).'
                                    
                                </div>
                                <!-- end showcase__desc -->
                                
                            </div>
                            <!-- end showcase__item -->
                            
                        </div>
                        <!-- end all showcase items container -->
                
                    </div>
                    <!-- end showcase slider -->
                    
                </div>
                <!-- end showcase inner -->
                
            </div>
            <!-- end showcase outer bgcolor -->
            
        </div>
        <!-- end showcase outer bgimage --> 
        
    </div>
    <!-- end showcase --> 
    ';

    return $output;
}
