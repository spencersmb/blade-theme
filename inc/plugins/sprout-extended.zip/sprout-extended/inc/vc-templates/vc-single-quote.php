<?php

function sprout_ext_single_quote()
{
    vc_map( array(
        "name"      => esc_html__( "Quote Item", "sprout_ext" ),
        "base"      => "single_quote_item",
        'icon'        => 'single_quote_item_icon',
        'description' => esc_html__( 'Add a single price panel.', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(
            array(
                'type' => 'checkbox',
                'heading' => esc_html__( 'Is this a premium product', 'sprout_ext' ),
                'param_name' => 'premium',
                "admin_label" => false,
                'description' => esc_html__( 'Add premium look to this item.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Title', 'sprout_ext' ),
                'param_name' => 'title',
                "admin_label" => true,
                'description' => esc_html__( 'Add title.', 'sprout_ext' ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__("Title Color", "sprout_ext"),
                "class" => "hide_in_vc_editor",
                "value" => '#222228',
                "param_name" => "title_color",
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Cost', 'sprout_ext' ),
                'param_name' => 'cost',
                "admin_label" => true,
                'description' => esc_html__( 'Add a price.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Short Description', 'sprout_ext' ),
                'param_name' => 'desc',
                "admin_label" => false,
                'description' => esc_html__( 'Add a short description of the plan.', 'sprout_ext' ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__("Description Text Color", "sprout_ext"),
                "value" => '#222228',
                "param_name" => "desc_color",
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Bullet Item 1', 'sprout_ext' ),
                'param_name' => 'bullet_1',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for a bullet.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Bullet Item 2', 'sprout_ext' ),
                'param_name' => 'bullet_2',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for a bullet.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Bullet Item 3', 'sprout_ext' ),
                'param_name' => 'bullet_3',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for a bullet.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Bullet Item 4', 'sprout_ext' ),
                'param_name' => 'bullet_4',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for a bullet.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Bullet Item 5', 'sprout_ext' ),
                'param_name' => 'bullet_5',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for a bullet.', 'sprout_ext' ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Button Text', 'sprout_ext' ),
                'param_name' => 'button_text',
                "admin_label" => false,
                'description' => esc_html__( 'Add text for the button.', 'sprout_ext' ),
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "heading" => esc_html__("Button Color", "sprout_ext"),
                "value" => '#53950C',
                "param_name" => "button_color",
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                'holder'      => 'div'
            )
        )
    ) );

}
sprout_ext_single_quote();
add_shortcode_param('icon' , 'sprout_ext_icon_field');

// [single_quote_item]
add_shortcode( 'single_quote_item', 'sprout_ext_single_quote_item_func' );
function sprout_ext_single_quote_item_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'premium' => '',
        'title' => '',
        'title_color' => '',
        'cost' => '',
        'desc' => '',
        'desc_color' => '',
        'bullet_1' => '',
        'bullet_2' => '',
        'bullet_3' => '',
        'bullet_4' => '',
        'bullet_5' => '',
        'button_text' => '',
        'button_color' => '',

    ), $atts ) );

    // preimium product
    $is_premium = $premium ? 'shadow-light premium' : '';

    // Build Output
    $output = '
        <!-- quote item select -->
        <div class="card__item quote__item single__item '.esc_attr($class).'">

            <div class="card__item--content '.$is_premium.'">
            
                <h2 style="color:'.esc_attr($title_color).'" >'. wp_kses($title, 'sprout_ext') .'</h2>';
    if( strlen($cost) > 0):
       $output .= '<span class="rounded-btn black-btn price black">'. wp_kses($cost, 'sprout_ext') .'</span>';
    endif;
    $output .= '
                <h3 class="desc">'. wp_kses($desc, 'sprout_ext') .'</h3>
                <ul class="card__list">';
    if( strlen($bullet_1) > 0):
        $output .= '
                    <li>
                        <i class="fa fa-check" aria-hidden="true"></i>'. wp_kses( $bullet_1 ,'sprout_ext') .'
                    </li>';
    endif;
    if( strlen($bullet_2) > 0):
        $output .= '
                    <li>
                        <i class="fa fa-check" aria-hidden="true"></i>'. wp_kses( $bullet_2 ,'sprout_ext') .'
                    </li>';
    endif;
    if( strlen($bullet_3) > 0):
        $output .= '
                    <li>
                        <i class="fa fa-check" aria-hidden="true"></i>'. wp_kses( $bullet_3 ,'sprout_ext') .'
                    </li>';
    endif;
    if( strlen($bullet_4) > 0):
        $output .= '
                    <li>
                        <i class="fa fa-check" aria-hidden="true"></i>'. wp_kses( $bullet_4 ,'sprout_ext') .'
                    </li>';
    endif;
    if( strlen($bullet_5) > 0):
        $output .= '
                    <li>
                        <i class="fa fa-check" aria-hidden="true"></i>'. wp_kses( $bullet_5 ,'sprout_ext') .'
                    </li>';
    endif;
        $output .= '
                </ul>
                
            </div>

        </div>
    ';

    return $output;
}