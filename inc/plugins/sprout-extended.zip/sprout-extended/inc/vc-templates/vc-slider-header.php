<?php
function sprout_ext_build_header_cats($color){
    $output = '';
    if(!strlen($color) > 0){
        $color = '';
    }
    $post_id = get_the_ID();
    // build categories
    $get_categories = get_the_category($post_id);
    $cat_arr = array();

    foreach ($get_categories as $category){
        $temp = array();
        $temp['name'] = $category->name;
        $temp['url'] = get_category_link( $category->cat_ID );
        array_push($cat_arr, $temp);

        $output .= '<a class="tag-btn" style="color:'.esc_attr($color).'; border-color:'.esc_attr($color).'" href="'.get_category_link( $category->cat_ID ).'">'.$category->name.'</a>';
    }

    return $output;

}

function sprout_ext_build_image_list($image_ids){
    $output = '';
    $image_urls = array();
    $count = 0;
    $string_images = explode(',', $image_ids, 20);
    if ( count($string_images) > 0 ) {
        foreach ($string_images as $image){

            $image_srcset = wp_get_attachment_image_srcset( $image, 'sprout-gallery-slider' );
            $image_src = wp_get_attachment_image_src( $image, 'sprout-gallery-slider' );
            if($count === 0){
                $output .= '<li class="selected">
                    <img 
                        class="img-responsive" 
                        src="'.$image_src[0].'" 
                        srcset="'. esc_attr($image_srcset) .'"
                        sizes="(max-width: 1920px) 100vw, 1920px"
                        alt="">
                    
                    </li>';
            }else{
                $output .= '<li>
                    <img 
                        class="img-responsive" 
                        src="'.wp_get_attachment_url($image).'" 
                        srcset="'. esc_attr($image_srcset) .'"
                        sizes="(max-width: 1920px) 100vw, 1920px"
                        alt="">
                    
                    </li>';
            }
            $count++;
        }
    }

    return $output;
}

function sprout_ext_header_slider_func() {
    vc_map( array(
        "name"      => esc_html__( "Header Slider", "sprout_ext" ),
        "base"      => "sprout_ext_header_slider",
        'icon'        => 'header_slider_icon',
        'description' => esc_html__( 'Create a Header Slider', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(

            array(
                "type" => "textarea",
                "holder" => "div",
                "heading" => esc_html__("Subtext", "sprout_ext"),
                "param_name" => "subtext",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Title Color", "sprout_ext"),
                "param_name" => "title_color",
                "value" => "#35373d",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Subtitle Color", "sprout_ext"),
                "param_name" => "subtitle_color",
                "value" => "#35373d"
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Categories Color", "sprout_ext"),
                "param_name" => "cat_color",
                "value" => "#78be01"
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Breadcrumbs Color", "sprout_ext"),
                "param_name" => "bread_color",
                "value" => "#8c8c8c",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Divider Color", "sprout_ext"),
                "param_name" => "divider_color",
                "value" => "#fff",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => esc_html__("Layout Background Color", "sprout_ext"),
                "param_name" => "layout_bg_color",
                "value" => "#fff"
            ),
            array(
                "type" => "attach_images",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => false,
                "heading" => "Slider Images",
                "description" => esc_html__( "Choose multiple images to add to the slider. Image size: 1600x1200", "sprout_ext" ),
                "param_name" => "images",
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )
    ) );

};
sprout_ext_header_slider_func();

function sprout_ext_header_slider_shortcode($params = array(), $content = null) {
    extract(shortcode_atts(array(
        'subtext' => '',
        'title_color' => '#35373d',
        'subtitle_color' => '#35373d',
        'cat_color' => '#78be01',
        'bread_color' => '#8c8c8c',
        'divider_color' => '#fff',
        'layout_bg_color' => '#fff',
        'images' => '',
        'class' => ''
    ), $params));

    $post_title='';

    $post_id = get_the_ID();
    // build categories
    $get_categories = get_the_category($post_id);
    $cat_arr = array();

    $sprout_ext_header_slider = '
    <!-- slider section -->
	<section class="header-slider-container no-padding '. esc_attr($class) .'">
        <div class="header-slider-inner">
            <div class="header-slider-content shadow-medium" style="background-color:'. esc_attr($layout_bg_color) .'">
                <div class="header-slider-wrapper">
                
                    <ul class="header-slider-gallery">
                        '.sprout_ext_build_image_list($images).'
                    </ul>
                    
                    <ul class="header-slider-navigation">
                        <li><a href="#" class="slider-navigation-prev">Prev</a></li>
                        <li><a href="#" class="slider-navigation-next">Next</a></li>
                    </ul>
                    
                    <div class="count"><span class="current">1</span> / <span class="total"></span></div>
                    
                    <a href="#" class="neat-close header-slider-close">Close</a>
                </div>
                <div class="header-slider-desc">
                    
                    <div class="header-slider-breadcrumb">
                        '.wp_kses_post(neat_breadcrumbs(array('color'=> $bread_color))).'
                    </div>
                    
                    <h2 style="color:'.esc_attr($title_color).'">' . get_the_title() . '</h2>
                    
                    <p style="color:'.esc_attr($subtitle_color).'">' . wp_kses($subtext, 'sprout_ext') . '</p>
                    
                </div>
                <div class="header-slider-meta">
                    '.wp_kses_post(sprout_ext_build_header_cats($cat_color), 'sprout_ext').'
                </div>
            </div>
        </div>
        <div class="header-slider-divider">
           <div class="divider-svg">
                <svg xmlns="http://www.w3.org/2000/svg" width="1200" height="65" viewBox="0 0 1212.4 64.6" class="divider-svg">
                    <polygon points="606.2 40.9 0 0 0 64.6 595.2 64.6 617.2 64.6 1212.4 64.6 1212.4 0 " fill="'.esc_attr($divider_color).'" class="divider-path"/>
                </svg>
           </div>
		</div>
	</section>
	<!-- end slider section -->
	';


    return $sprout_ext_header_slider;
}
add_shortcode('sprout_ext_header_slider', 'sprout_ext_header_slider_shortcode');