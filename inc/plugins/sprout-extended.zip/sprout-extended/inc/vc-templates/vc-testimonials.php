<?php

function sprout_ext_testimonials_vc_func() {
    vc_map( array(
        "name"      => esc_html__( "Testimonials Slider", "sprout_ext" ),
        "base"      => "testimonials",
        'icon'        => 'testimonials_icon',
        "as_parent" => array('only' => 'testimonials_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "is_container" => true,
        "js_view" => 'VcColumnView',
        'description' => esc_html__( 'List of feature testimonials posts.', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(
            array(
                'param_name'  => 'has_timer',
                'heading'     => esc_html__( 'Add Autoplay', 'sprout_ext' ),
                'description' => esc_html__( 'Check to add autoplay rotation to the slider', 'sprout_ext' ),
                'type'        => 'checkbox',
                "value"			=> ''
            ),
            array(
                'param_name'  => 'speed',
                'dependency' => array(
                    'element' => 'has_timer',
                    'value' => array('true')
                ),
                "heading" => esc_html__( "Cycle Speed", "sprout_ext" ),
                "description" => esc_html__( "Set the rotation speed. 1 sec = 1000. If you want a 6 sec delay type 6000 in the box", "sprout_ext" ),
                "type" => "textfield",
                "value" => '6000',
            ),
            array(
                'param_name'  => 'margin_top',
                'heading'     => esc_html__( 'Margin Top', 'sprout_ext' ),
                'description' => esc_html__( 'Enter spacing for the top of the slider in px', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                'holder'      => 'div'
            ),
            array(
                'param_name'  => 'margin_bottom',
                'heading'     => esc_html__( 'Margin Bottom', 'sprout_ext' ),
                'description' => esc_html__( 'Enter spacing for the top of the slider in px', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                'holder'      => 'div'
            ),
            array(
                'param_name'  => 'margin_left_right',
                'heading'     => esc_html__( 'Margin Left and Right', 'sprout_ext' ),
                'description' => esc_html__( 'Enter spacing to the left and right of the slider in px', 'sprout_ext' ),
                'type'        => 'textfield',
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                'holder'      => 'div'
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )
    ) );
    vc_map( array(
        "name"      => esc_html__( "Testimonial Item", "sprout_ext" ),
        "base"      => "testimonials_item",
        'icon'        => 'testimonials_item_icon',
        "as_child" => array('only' => 'testimonials'),
        'description' => esc_html__( 'Add an item to the testimonial slider.', 'sprout_ext' ),
        "wrapper_class" => "clearfix",
        "category" => esc_html__( 'Content', 'sprout_ext' ),
        "params"    => array(
            array(
                "type" => "textarea",
                "holder" => "div",
                "heading" => esc_html__( "Quote", "sprout_ext" ),
                "param_name" => "quote",
                "class" => "hide_in_vc_editor",
                "value" => '',
                "description" => esc_html__( "Add a quote here.", "sprout_ext" )
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__( "Quote Text Color", "sprout_ext" ),
                "param_name" => "quote_text_color",
                "class" => "hide_in_vc_editor",
                "value" => '#fff', //Default P color
                "description" => esc_html__( "Choose a text color.", "sprout_ext" )
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__( "Author Name", "sprout_ext" ),
                "param_name" => "author",
                "value" => '',
                "description" => esc_html__( "Add an author.", "sprout_ext" )
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__( "Author text color", "sprout_ext" ),
                "param_name" => "author_text_color",
                "class" => "hide_in_vc_editor",
                "value" => '#222228', //Default P color
                "description" => esc_html__( "Choose a text color.", "sprout_ext" )
            ),
            array(
                "type" => "attach_image",
                "holder" => "div",
                "class" => "hide_in_vc_editor",
                "admin_label" => true,
                "heading" => "Background Image",
                "param_name" => "bg_image",
            ),
            array(
                "type" => "colorpicker",
                "holder" => "div",
                "heading" => esc_html__( "Overlay color", "sprout_ext" ),
                "param_name" => "overlay_color",
                "class" => "hide_in_vc_editor",
                "value" => '#8ED72B', //Default P color
                "description" => esc_html__( "Choose overlay fade color", "sprout_ext" )
            ),
            array(
                'param_name'  => 'class',
                'heading'     => esc_html__( 'Class', 'sprout_ext' ),
                'description' => esc_html__( '(Optional) Enter a unique class name.', 'sprout_ext' ),
                'type'        => 'textfield',
                'holder'      => 'div'
            )
        )
    ) );

    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_Testimonials extends WPBakeryShortCodesContainer {
        }
    }

};
sprout_ext_testimonials_vc_func();

// [testimonials]
add_shortcode( 'testimonials', 'sprout_ext_testimonials_shortcode' );
function sprout_ext_testimonials_shortcode( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'speed' => '',
        'has_timer' => '',
        'class' => '',
        'margin_top' => '50px',
        'margin_bottom' => '50px',
        'margin_left_right' => '50px',

    ), $atts ) );

    $content = do_shortcode($content);

    // Default Speed
    if($has_timer === 'true'){
        $speed = '6000';
    }else{
        $speed = 'false';
    }

    $output = '
        
        <div id="carousel-testimonial" class="testimonials carousel slide shadow-medium-dark'. esc_attr($class) .'" data-ride="carousel-testimonial" data-interval="'.esc_attr($speed).'">
         
          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
          
            '.$content.'
            
          </div>
        
          <!-- Controls -->
          <div class="control-wrapper">
              <div class="control-inner">
                  <a class="left carousel-control" href="#carousel-testimonial" role="button" data-slide="prev">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>
                    <span class="sr-only">'.esc_html__('Previous', 'sprout_ext').'</span>
                  </a>
                  <a class="right carousel-control" href="#carousel-testimonial" role="button" data-slide="next">
                    <i class="fa fa-chevron-right" aria-hidden="true"></i>
                    <span class="sr-only">'.esc_html__('Next', 'sprout_ext').'</span>
                  </a>
              </div>
          </div>
        </div>
    ';


    return $output;
}

add_shortcode( 'testimonials_item', 'sprout_ext_testimonials_item_func' );
function sprout_ext_testimonials_item_func( $atts, $content = null ) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'class' => '',
        'quote' => '',
        'bg_image' => '',
        'overlay_color' => '',
        'quote_text_color' => '#fff',
        'author_text_color' => '#222228',
        'author' => ''

    ), $atts ) );

    // Default Color
    if($overlay_color === ''){
        $overlay_color = '#8ED72B';
    }

    // Image Check
    if (is_numeric($bg_image)) {
        $bg_image = wp_get_attachment_url($bg_image);
    }

    // Build Output
    $output = '
        <div class="item testimonial-item '. esc_attr($class) .'" style="background-image: url('. esc_url($bg_image). ');">
            
            <blockquote style="color:'. esc_attr($quote_text_color) .'">
                <q>'. wp_kses($quote, 'sprout_ext') .'</q>
                <cite style="color:'. esc_attr($author_text_color) .'">-'. wp_kses($author, 'sprout_ext') .'</cite>
            </blockquote>
            
            <div class="testimonial-color-block" style="background-color: '. esc_attr($overlay_color). ';"></div>
        </div>
    ';

    return $output;
}
