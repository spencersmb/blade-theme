<?php
/**
 * Plugin Name: About Widget
 */

add_action( 'widgets_init', function(){
    register_widget( 'sprout_ext_about_widget' );
} );

class sprout_ext_about_widget extends WP_Widget {
        var $textdomain;
    /**
     * Sets up the widget
     */
    public function __construct() {
        $this->textdomain = 'sprout_ext_about_widget';
        /* Widget settings. */
        $widget_ops = array(
            'classname' => 'sprout_ext_about_widget',
            'description' => __('A widget that displays an About widget', 'sprout_ext_about_widget')
        );

        /* Widget control settings. */
        $control_ops = array(
            'width' => 250, 'height' => 350,
            'id_base' => 'sprout_ext_about_widget'
        );

        add_action( 'load-widgets.php', array(&$this, 'my_custom_load') );

        /* Create the widget. */
        parent::__construct( 'sprout_ext_about_widget', __('Neat: About Us', 'sprout_ext_about_widget'), $widget_ops, $control_ops );
    }

    /**
     * Load WP-ColorPicker library.
     */
    function my_custom_load() {
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_script( 'underscore' );

        // Media Select scripts
        wp_enqueue_script('media-upload');
        wp_enqueue_script('thickbox');
        wp_enqueue_script('upload_media_widget', plugin_dir_url(__FILE__) . 'upload-media.js', array('jquery'));

        wp_enqueue_style('thickbox');
    }
    /**
     * How to display the widget on the screen.
     */
    function widget( $args, $instance ) {
        extract( $args );

        $shortcode_args = array(
            'li' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'i' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'a' => array(
                'style'=> array(),
                'class'=> array()
            )
        );

        /* Our variables from the widget settings. */
        $title = apply_filters('widget_title', $instance['title'] );
        $description = $instance['description'];
        $image = $instance['image'];
        $background_color = $instance['background_color'];
        $font_color = $instance['font_color'];
        $round = $instance['round'];

        /* Before widget (defined by themes). */
        echo $before_widget;

//        echo "<pre>";
//        print_r($instance);
//        echo "</pre>";

        ?>

        <div class="about-widget" style="
            background-color: <?php echo esc_attr($background_color)?>;
            <?php if($round) : ?>
                border-radius: 5px
            <?php endif; ?>
            ">

            <?php if($image) : ?>
                <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_html($title); ?>" class="about-image"/>
            <?php endif; ?>

            <?php if($title) : ?>
                <h3 style="color: <?php echo esc_attr($font_color)?>"><?php echo wp_kses($title, 'sprout_ext_about_widget'); ?></h3>
            <?php endif; ?>
            <?php if($description) : ?>
                <p style="color: <?php echo esc_attr($font_color)?>"><?php echo wp_kses($description, 'sprout_ext_about_widget'); ?></p>
            <?php endif; ?>

        </div>

        <?php

        /* After widget (defined by themes). */
        echo $after_widget;
    }

    /**
     * Update the widget settings.
     */
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $updated_instance = $new_instance;

        /* Strip tags for title and name to remove HTML (important for text inputs). */
//        $instance['title'] = strip_tags( $new_instance['title'] );
//        $instance['image'] = strip_tags( $new_instance['image'] );
//        $instance['description'] = $new_instance['description'];
//        $instance['background_color'] = strip_tags($new_instance['background_color']);
//        $instance['font_color'] = strip_tags($new_instance['font_color']);
//        $instance['round'] = $new_instance['round'];

//        return $instance;
        return $updated_instance;
    }


    function form( $instance ) {

        /* Set up some default widget settings. */
        $defaults = array(
            'title' => '',
            'image' => '',
            'description' => '',
            'round' => '',
            'background_color' => '#fff',
            'font_color' => '#fff',
        );

        $image = '';
        if(isset($instance['image']))
        {
            $image = $instance['image'];
        }

        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <!-- Widget Title: Text Input -->

        <p>

            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo wp_kses('Title:', 'sprout_ext') ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:96%;" />
        </p>

        <!-- image upload -->
        <p>
            <label for="<?php echo $this->get_field_name( 'image' ); ?>"><?php _e( 'Image:' ); ?></label>
            <input name="<?php echo $this->get_field_name( 'image' ); ?>" id="<?php echo $this->get_field_id( 'image' ); ?>" class="widefat" type="text" size="36"  value="<?php echo esc_url( $image ); ?>" />
            <input class="upload_image_button button button-primary" type="button" value="Upload Image" />
        </p>

        <!-- description -->
        <p>
            <label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php echo wp_kses('About me text:', 'sprout_ext') ?></label>
            <textarea id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" style="width:95%;" rows="6"><?php echo $instance['description']; ?></textarea>
        </p>

        <!-- round image -->
        <p>
            <label for="<?php echo $this->get_field_id( 'round' ); ?>"><?php echo wp_kses('Add Rounded Corners:', 'sprout_ext') ?></label>
            <input type="checkbox" id="<?php echo $this->get_field_id( 'round' ); ?>" name="<?php echo $this->get_field_name( 'round' ); ?>" <?php checked( (bool) $instance['round'], true ); ?> /><br />
        </p>

        <!-- background color -->
        <script>
            ( function( $ ){
                function initColorPicker( widget ) {
                    widget.find( '.color-picker' ).wpColorPicker( {
                        change: _.throttle( function() { // For Customizer
                            $(this).trigger( 'change' );
                        }, 3000 )
                    });
                }

                function onFormUpdate( event, widget ) {
                    initColorPicker( widget );
                }

                $( document ).on( 'widget-added widget-updated', onFormUpdate );

                $( document ).ready( function() {
                    $( '#widgets-right .widget:has(.color-picker)' ).each( function () {
                        initColorPicker( $( this ) );
                    } );
                } );
            }( jQuery ) );
        </script>
        <p>
            <label class="widget-color-picker" for="<?php echo $this->get_field_id( 'background_color' ); ?>"><?php echo wp_kses('Select Background Color:', 'sprout_ext') ?></label>
            <input class="color-picker" type="text" id="<?php echo $this->get_field_id( 'background_color' ); ?>" name="<?php echo $this->get_field_name( 'background_color' ); ?>" value="<?php echo esc_attr( $instance['background_color'] ); ?>" />
        </p>

        <p>
            <label class="widget-color-picker" for="<?php echo $this->get_field_id( 'font_color' ); ?>"><?php echo wp_kses('Select Font Color:', 'sprout_ext') ?></label>
            <input class="color-picker" type="text" id="<?php echo $this->get_field_id( 'font_color' ); ?>" name="<?php echo $this->get_field_name( 'font_color' ); ?>" value="<?php echo esc_attr( $instance['font_color'] ); ?>" />
        </p>

        <?php
    }
}
