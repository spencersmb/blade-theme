<?php
/**
 * Plugin Name: Hours Widget
 */

add_action( 'widgets_init', function(){
    register_widget( 'sprout_ext_hours_widget' );
} );

class sprout_ext_hours_widget extends WP_Widget {

    /**
     * Sets up the widget
     */
    public function __construct() {

        /* Widget settings. */
        $widget_ops = array(
            'classname' => 'sprout_ext_hours_widget',
            'description' => esc_html__('A widget that displays operation hours', 'sprout_ext_hours_widget')
        );

        /* Widget control settings. */
        $control_ops = array(
            'width' => 250, 'height' => 350,
            'id_base' => 'sprout_ext_hours_widget'
        );

        /* Create the widget. */
        parent::__construct( 'sprout_ext_hours_widget', esc_html__('Neat: Hours', 'sprout_ext_hours_widget'), $widget_ops, $control_ops );
    }

    /**
     * How to display the widget on the screen.
     */
    function widget( $args, $instance ) {
        extract( $args );

        $shortcode_args = array(
            'li' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'i' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'a' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'span' => array(
                'style'=> array(),
                'class'=> array()
            )
        );

        /* Our variables from the widget settings. */
        $title = apply_filters('widget_title', $instance['title'] );
        $description = $instance['description'];
        $list = $instance['hours_list'];

        /* Before widget (defined by themes). */
        echo $before_widget;

        /* Display the widget title if one was input (before and after defined by themes). */
        if ( $title )
            echo $before_title . $title . $after_title;

        ?>

        <div class="hours-widget">

            <?php if($description) : ?>
                <p><?php echo wp_kses_post($description); ?></p>
            <?php endif; ?>

            <?php if($list) : ?>
                <div class="hours-wrapper">
                    <h6 class="hours-widget-title"><?php echo wp_kses('Weekly Hours', 'sprout_ext') ?></h6>
                    <ul class="hours-list"><?php echo wp_kses(do_shortcode($list), $shortcode_args, 'sprout_ext'); ?></ul>
                </div>
            <?php endif; ?>

        </div>

        <?php

        /* After widget (defined by themes). */
        echo $after_widget;
    }

    /**
     * Update the widget settings.
     */
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        /* Strip tags for title and name to remove HTML (important for text inputs). */
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['description'] = $new_instance['description'];
        $instance['hours_list'] = $new_instance['hours_list'];

        return $instance;
    }


    function form( $instance ) {

        /* Set up some default widget settings. */
        $defaults = array(
            'title' => '',
            'description' => '',
            'hours_list' => ''
        );

        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <!-- Widget Title: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo wp_kses('Title:', 'sprout_ext') ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:96%;" />
        </p>

        <!-- description -->
        <p>
            <label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php echo wp_kses('Description', 'sprout_ext') ?></label>
            <textarea id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" style="width:95%;" rows="6"><?php echo $instance['description']; ?></textarea>
        </p>

        <!-- description -->
        <p>
            <label for="<?php echo $this->get_field_id( 'hours_list' ); ?>"><?php echo wp_kses('Hours List:', 'sprout_ext') ?></label>
            <textarea id="<?php echo $this->get_field_id( 'hours_list' ); ?>" name="<?php echo $this->get_field_name( 'hours_list' ); ?>" style="width:95%;" rows="16"><?php echo $instance['hours_list']; ?></textarea>
        </p>

        <?php
    }
}