<?php
/**
 * Plugin Name: List Services Widget
 */

add_action( 'widgets_init', function(){
    register_widget( 'sprout_ext_services_widget' );
} );

class sprout_ext_services_widget extends WP_Widget {

    /**
     * Sets up the widget
     */
    public function __construct() {


        /* Widget settings. */
        $widget_ops = array(
            'classname' => 'sprout_ext_services_widget',
            'description' => esc_html__('A widget that lists Services', 'sprout_ext_services_widget')
        );

        /* Widget control settings. */
        $control_ops = array(
            'width' => 250, 'height' => 350,
            'id_base' => 'sprout_ext_services_widget'
        );



        /* Create the widget. */
        parent::__construct( 'sprout_ext_services_widget', esc_html__('Neat: Services List', 'sprout_ext_services_widget'), $widget_ops, $control_ops );
    }


    /**
     * How to display the widget on the screen.
     */
    function widget( $args, $instance ) {
        extract( $args );

        $shortcode_args = array(
            'h6' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'li' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'i' => array(
                'style'=> array(),
                'class'=> array()
            ),
            'a' => array(
                'style'=> array(),
                'class'=> array()
            )
        );

        /* Our variables from the widget settings. */
        $title = apply_filters('widget_title', $instance['title'] );

        /* Before widget (defined by themes). */
        echo $before_widget;

        ?>

        <div class="service-list-widget">
             <?php wp_nav_menu( array( 'theme_location' => 'service' ) ); ?>
        </div>

        <?php

        /* After widget (defined by themes). */
        echo $after_widget;
    }

    /**
     * Update the widget settings.
     */
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        /* Strip tags for title and name to remove HTML (important for text inputs). */
        $instance['title'] = strip_tags( $new_instance['title'] );

        return $instance;
    }


    function form( $instance ) {

        /* Set up some default widget settings. */
        $defaults = array(
            'title' => 'Services',
        );

        $instance = wp_parse_args( (array) $instance, $defaults );

        ?>
        <!-- Widget info -->
        <p>
            <?php echo esc_html__('Add items via the secondary Service Menu', 'ext_neat') ?>
        </p>

        <?php
    }
}