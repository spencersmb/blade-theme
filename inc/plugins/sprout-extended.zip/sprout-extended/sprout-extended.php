<?php
/*
Plugin Name: Sprout Custom Post Types / Widgets / Shortcodes
Plugin URI:  http://tuesdaythemes.com/theblade/plugins/sprout_ext
Description: This plugin extends functionality for Sprout Landscape WordPress Theme
Version:     1.0
Author:      Spencer Bigum
Author URI:  http://tuesdaythemes.com/theblade/
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: sprout_ext
*/

$PATH = plugin_dir_path( __FILE__ );

/**
 * Add Theme Custom Post Types
 */
include_once( $PATH . 'inc/cpt.php');

/**
 * Add Gallery Custom Filter types
 */
include_once( $PATH . 'inc/cpt_tax.php');

/**
 * Enable Custom Widgets
 */
include_once( $PATH . 'inc/widgets/about_widget.php');
include_once( $PATH . 'inc/widgets/contact_widget.php');
include_once( $PATH . 'inc/widgets/hours_widget.php');
include_once( $PATH . 'inc/widgets/social_widget.php');
include_once( $PATH . 'inc/widgets/recent_posts.php');
include_once( $PATH . 'inc/widgets/service_list_widget.php');

/**
 * Visual Composer Custom Templates
 */
require_once( $PATH . 'inc/vc-templates.php');

/**
 * Theme Shortcodes
 */

add_action('init', 'sprout_ext_register_shortcodes');
function sprout_ext_register_shortcodes()
{

    add_shortcode('list_item', 'sprout_ext_list_item_icon_shortcode');
    add_shortcode('hours', 'sprout_ext_hours_item_shortcode');
}

/* Widget Time Shortcodes */
function sprout_ext_list_item_icon_shortcode( $args, $content="" ){

    $icon = '';
    $output = '';

    if( isset($args['icon']) ): $icon = $args['icon']; endif;

    $output .= '<li><i class="fa fa-'. esc_attr($icon) .' fa-lg"></i>'. wp_kses($content, 'sprout_ext') .'</li>';

    //return our results
    return $output;
}
function sprout_ext_hours_item_shortcode( $args, $content="" ){

    $open = '';
    $close = '';
    $output = '';

    if( isset($args['open']) ): $open = $args['open']; endif;
    if( isset($args['close']) ): $close = $args['close']; endif;

    if(strlen($open) > 0):
        $output .= '<li><span class="hours-widget-day">'. wp_kses($content, 'sprout_ext') .'</span><span class="hours-widget-time">'. wp_kses($open, 'sprout_ext') .' - '. wp_kses($close, 'sprout_ext') .'</span></li>';
    else:
        $output .= '<li><span class="hours-widget-day">'. wp_kses($content, 'sprout_ext') .'</span><span class="hours-widget-time closed">Closed</span></li>';
    endif;

    //return our results
    return $output;
}



